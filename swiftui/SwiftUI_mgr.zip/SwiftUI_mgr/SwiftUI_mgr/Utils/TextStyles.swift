//
//  TextStyles.swift
//  SwiftUI_mgr
//
//  Created by Łukasz Czapkowski on 20/01/2025.
//

import Foundation
import SwiftUI

extension TextFieldStyle {
//    public static let headerCell: Font {
//        return .init()
//    }
}
