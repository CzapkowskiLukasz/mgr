//
//  SwiftUI_mgrTests.swift
//  SwiftUI_mgrTests
//
//  Created by Łukasz Czapkowski on 02/01/2025.
//

import Testing

struct SwiftUI_mgrTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
